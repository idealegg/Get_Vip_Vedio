document.writeln('<script>');
document.writeln('var _hmt = _hmt || [];');
document.writeln('(function() {');
document.writeln('  var hm = document.createElement("script");');
document.writeln('  hm.src = "https:\/\/hm.baidu.com\/hm.js?79d909c9de7627d63e1d0ac24093550f";');
document.writeln('  var s = document.getElementsByTagName("script")[0]; ');
document.writeln('  s.parentNode.insertBefore(hm, s);');
document.writeln('})();');
document.writeln('<\/script>');
