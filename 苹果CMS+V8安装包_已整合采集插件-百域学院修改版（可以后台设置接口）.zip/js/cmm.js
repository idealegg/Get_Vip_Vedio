var qbfq =["http:\/\/app.baiyug.cn:2019\/vip\/?url="]
var qbfd ="http://app.baiyug.cn:2019/vip/?url="