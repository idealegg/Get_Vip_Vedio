for(var o in qbfq)
 { 
var r=qbfq[o]
var h=o
if(h==0){
g = "A"
}
if(h==1){
g = "B"
}
if(h==2){
g = "C"
}
if(h==3){
g = "D"
}
if(h==4){
g = "E"
}
if(h==5){
g = "F"
}

document.write('<a style="text-decoration:none;" href="'+r+MacPlayer.PlayUrl+'" target= "iFrame1" > '+g+'线 </a>')
  
}  
	  