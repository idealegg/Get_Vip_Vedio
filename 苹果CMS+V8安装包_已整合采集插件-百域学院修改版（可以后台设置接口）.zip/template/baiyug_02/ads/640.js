﻿document.writeln("<div class=\"ui-sponsor\"><a href=\"http:\/\/3344.baiyug.cn\/\"><img alt=\"960-90\" src=\"" width=\"480\" height=\"60\" \/><\/a><\/div>")
