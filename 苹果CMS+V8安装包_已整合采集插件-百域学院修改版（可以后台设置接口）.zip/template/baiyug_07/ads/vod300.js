﻿document.write('<img src=\''+SitePath+'template/baiyug_05_sp/images/300x250.jpg\' />')
